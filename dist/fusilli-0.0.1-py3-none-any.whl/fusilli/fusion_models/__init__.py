"""
Fusion models: one py file per model
"""
