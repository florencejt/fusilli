from .synthetic import SyntheticDataset


__all__ = [
	'SyntheticDataset',
]
