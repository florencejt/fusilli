"""
Graph fusion template
=====================
"""
