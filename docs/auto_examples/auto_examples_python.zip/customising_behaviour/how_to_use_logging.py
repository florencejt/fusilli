"""
How to use Weights and Biases Logging with Fusilli
====================================================================

"""
