"""
How to customise the training in Fusilli
#########################################

* Early stopping
* Batch size
* Number of epochs
* Checkpoint suffixes

.. note::

    Coming soon!

"""
