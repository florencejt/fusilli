"""
Subspace fusion template
========================

"""
